//Make it Big
function makeItBig (arr){
    arr=[];
    for (var i=0; i<arr.length; i++){
        if (arr[i] > 0){
            arr[i] = "big"
        }
    }
    return arr
}
makeItBig()


//Print Low, Return High
function lowHigh(arr){
    var arr =[1,3,5,7];
    var max =arr[0];
    var min =arr[0];
    for (var i=0; i<arr.length; i++){
        if( max > arr[i]){
            max = arr[i];
        }
        if (min < arr[i]){
            min = arr[i];
        }
    }
    console.log(min);
    return max
}
lowHigh()


//Print One, Return Another
function OneAnother (arr){
    var arr=[1,3,5,7,9];
    var one = arr[i];
    var another = arr[i];
    for (var i=0; i<arr.length; i++){
        if (i = arr.length -2){
            one = arr[i]
        }
        if (i = arr.length -1){
            another = arr[i]
        }
    }
    console.log(one);
    return another
}
OneAnother()

//Double Vision
function double(arr){
    var arr=[1,2,3,4];
    var newArr=[];
    for (var i=0; i<arr.length; i++){
        newArr.push(arr[i] *2)
    }
    console.log(arr);
    return newArr
}
double()

//Count Positives
function positives(arr){
    var arr = [-1,1,1,1];
    num=0;
    for (var i=0; i<arr.length; i++){
        if (arr[i] > 0){
            num += 1
        }
    }
    arr[arr.length -1] = num;
    return arr
}
positives()

//Evens and Odds
function evensAndOdds(arr){
    var arr=[1,2,3,4,5,6,7,8,9,10];
    var odds = 0;
    var evens = 0;
    for (var i=0; i<arr.length; i++){
        if(arr[i] ==0){
        } else if (arr[i] % 2 !==0){
            odds +=1;
            if (odds == 3){
                console.log("That is odd!");
                odds = 0;
                evens = 0;
            }
            }else {
            evens += 1;
            if (evens ==3){
                console.log("Even more so!");
                evens = 0;
                odds = 0;
            }
        }
    }
}
evensAndOdds()

//Increment seconds
function seconds(arr){
    var arr = [1,3,5,7];
    var newArr = [];
    for (var i=0; i<arr.length;i++){
        if (i%2 !==0){
            arr[i] =(arr[i] +1)
        }
    }
    console.log(arr);
    return newArr
}
seconds()

//Previous Lengths
function prevLength (arr){
    newArr = [];
    arr = ["oklahoma", "sooner", "saban"];
    for(var i=0; i<arr.length; i++){
        newArr[i] = arr[i].length;
    }
    for (var y=1, x=0; y<arr.length; y++, x++){
        arr[y] = newArr[x];
    }
    return arr;
}
prevLength()

//Add Seven
function seven(arr){
    var arr = [1,2,3];
    newArr= [];
    for (var i = 0; i<arr.length; i++){
        newArr[i] = (arr[i]+7)
    }
    return newArr
}
seven()

//Reverse Array
function reverse(arr){
    var arr=[1,2,3,4,5];
    newArr = [];
    for (var i=0; i<arr.length; i++){
        newArr = arr.reverse(arr);
    }
    return newArr
}
reverse()

//
function negative(){
    var arr = [1,2,-1];
    var newArr = [];
    for(var i = 0; i< arr.length; i++){
        if(arr[i] > 0){
            newArr.push(arr[i] * -1);
        }
        else{ 
            newArr.push(arr[i]);
        }
    }
    console.log(arr);
    return newArr
}
negative()

