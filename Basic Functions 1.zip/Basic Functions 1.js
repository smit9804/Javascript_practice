//Get 1 through 255
var x=[];
for(var i=1; i<256; i++){
    x.push(i);
}
console.log(x)


//Get even 100
function sum_even(){
    var sum=0;
    for(var i=0; i<=1000; i++){
        if( i % 2 ==0){
            sum += i;
        }
    }
return (sum);
}
sum_even()


//Sum odd 5000
function sum_odd(){
    var sum = 0;
    for(var i=1; i < 5001; i++){
        if( i % 2 !== 0){
            sum += i;
        }
    }
    return sum;
}
sum_odd()


//Iterate the array
function iter(arr){
    var sum=0;
    for(i=0; i<arr.length; i++){
        sum = sum + arr[i];
    }
return sum;
}
iter()


//Find max
function Find_max(arr){
    var max= arr[0];
    for( var i =0; i<arr.length; i++){
        if(max<arr[i]){
            max = arr[i]
        }
    }
    return max;
}


//Find average
function find_avg(arr){
    var sum = 0;
    for(var i = 0; i<arr.length; i++){
        sum = sum + arr[i]
    }
    return sum/arr.length
}


//Array odd
function array_odd(arr){
    var odd = 0;
    for (var i = 0; i < arr.length; i++){
        if (i%2 !== 0){
            arr.push(i)
        }
    }
    return arr
}
array_odd()

//Grater than Y
function greater_y(arr, y){
    var count = 0
    for (var i=0; i<arr.length; i++){
        iff(arr[i] > y){
            count++;
        }
    }
    return count;
}


//Squares
function squareVal(arr){
    for (var i=0; i<arr.length; i++){
        arr[i] = arr[i] * arr[i]
    }
    return arr;
}
squareVal()


//Negatives
function noNeg(arr){
    for (var i=0; i<arr.length; i++){
        if (arr[i] < 0){
            arr[i] = 0
        }
    }
    return arr;
}
noNeg()


//max Min Avg
function maxMinAvg(arr){
    var max = arr[0];
    var min = arr[0];
    var sum = arr[0];

    for (var i =1; i<arr.length; i++){
        if (arr[i] > max){
            max = arr[1]
        }
        if (arr[i] <  min){
            min = arr[i]
        }
        sum = sum + arr[i];
    }
    var avg = sum / arr.length;
    var arrnew = [max,min,avg]
    return arrnew;
}
maxMinAvg


//Swap values
function swap(arr){
    var temp = arr[0];
    arr[0] = arr[arr.length - 1];
    arr[arr.length] = temp
    return arr;
} 
swap()


//Number to string
function numToStr(arr){
    for ( var i=0; i<arr.length; i++){
        if (arr[i] <0){
            arr[i] = 'Dojo'
        }
    }
    return arr;
}
numToStr()