var num= [6,3,5,1,2,4];
var sum=0;
for(var i = 0;i < num.length; i++){
    console.log("Num: " + num[i]);
    sum= sum + num[i];
    console.log("Sum: " + sum);
}

var num= [6,3,5,1,2,4];
var x =[];
for(var i = 0;i < num.length; i++){
    x[i] = i  * num[i];
    x.push[x];
}
console.log(x)