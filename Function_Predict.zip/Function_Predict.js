function greeting(){
        return "Hello";
        console.log("World");
    }
    var word = greeting();
    console.log(word);

    //returns Hello
    //logs World
    //word now equals the returned statement Hello
    //logs to the console: Hello

    //output is Hello

function add(num1, num2){
    console.log("Summing Numbers!");
        console.log("num1 is: " + num1);
        console.log("num2 is: " + num2);
        var sum = num1 + num2;
        return sum;
    }
    var result1 = add(3,5);
    var result2 = add(4,7);
    console.log(result1);
    console.log(result2);

    //logs: Summing Numbers!
    //logs num1 is: first number
    //logs: num2 is: second number
    //creates variable sum = first number plus second number
    //returns the sum to the console.
    //output is 8,11

    function highFive(num){
            for(var i=0; i<num; i++){
                if(i == 5){
                    console.log("High Five!");
                }
                else{
                    console.log(i);
                }
            }
        }

        //nothing will be returned since the function has not been called.
        //inside the function, it will show 1,2,3,4,High Five!